NEONDROP Supercars Cases Import Package
Contains 6 cases with authentic vehicles and items (4,000 - 45,000 UC).
