NEONDROP CASE IMPORT

6 cases with supplied case images, prices and target RTP.
Maximum item price: 45,000 UC.

IMPORTANT: individual item names/photos were not supplied, so the item names in cases.json are generated placeholders. Replace them with real items/photos before production import. Probabilities are mathematically constructed to match the requested target RTP for the generated price ladder.
